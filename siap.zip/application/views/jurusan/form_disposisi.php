<?php include 'head.php';?>
<div class="col-md-6">
<form class="form-group">
<input class="form-control"/>
</form>
</div>
<div class="col-md-6">
<iframe width="100%" height="280px" class="iframe" name="data" src="<?php echo site_url('jurusan/disposisi_perwalian/tabel_matkul');?>"></iframe>
</div>

   
