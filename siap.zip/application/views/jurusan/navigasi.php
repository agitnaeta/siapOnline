                <div class="panel panel-primary">
                        <div class="panel-heading">
                             <h5>
                                 <i class="glyphicon glyphicon-th-large"></i> Menu                                                                 </h5>
						</div>
                        <div class="panel-body">
							<a href="<?php echo site_url('jurusan/utama') ;?>"  class="list-group-item">
                                <i class="glyphicon glyphicon-home "></i> Menu Utama</a>
					
                      
							<a href="<?php echo site_url('jurusan/setting_kurikulum') ;?>" class="list-group-item ">
                                <i class="glyphicon glyphicon-tasks"></i> Setting Kurikulum</a>
						
                        
							<a href="<?php echo site_url('jurusan/disposisi_perwalian') ;?>" class="list-group-item ">
                                <i class="glyphicon glyphicon-pencil"></i> Disposisi perwalian</a>
						
                      
							<a href="<?php echo site_url('jurusan/cek_perwalian') ;?>" class="list-group-item" role="tab" data-toggle="tab">
                                <i class="glyphicon glyphicon-file"></i> Cek Perwalian </a>
					
                        
							<a href="<?php echo site_url('jurusan/entry_nilai') ;?>"  class="list-group-item ">
                                <i class="glyphicon glyphicon-download"></i> Entry Nilai</a>
					
                        
							<a href="<?php echo site_url('jurusan/kelola_krs') ;?>"  class="list-group-item ">
                                <i class="glyphicon glyphicon-file"></i> Kelola KRS</a>
					
                       
							<a href="<?php echo site_url('jurusan/kelola_khs');?>" class="list-group-item ">
                                <i class="glyphicon glyphicon-file"></i> Kelola KHS</a>	
								
							<a href="<?php echo site_url('jurusan/nilai_sementara');?>" class="list-group-item ">
                                <i class="glyphicon glyphicon-tasks"></i> Cek Daftar Nilai Sementara</a>
								
							<a href="<?php echo site_url('jurusan/utama/form_update');?>" class="list-group-item ">
                                <i class="glyphicon glyphicon-wrench"></i> Ubah Detail Akun</a>
                           
						</div>
                        <div class="panel-footer">
							<a href="<?php echo site_url('jurusan/utama/logout') ;?>" class="list-group-item ">
                                <i class="glyphicon glyphicon-off"></i> Selesai</a>
						</div>
					</div>