<a href="javascript:windows.print()" title="Klik Dimana Saja Untuk Print"> <!DOCTYPE HTML>
<html lang="id">
<head>
<title>BAAK | Kelola User</title>
<link href="<?php echo base_url(); ?>src/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>src/css/flat.css" rel="stylesheet">
<script type="text/javascript" src="<?php echo base_url(); ?>src/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>src/js/bootstrap.min.js"></script>
</head>
    
    <body>
        <div class="container">
        <div class="row-clearfix"><div class="col-md-2">4</div>
        <div class="col-md-8">
        <table class="table table-condensed ">
          <tr>
            <th colspan="4" class="text-center text-bold"><h4>KARTU HASIL STUDI<br>STMIK-SUMEDANG</h4></th>
          </tr>
          <tr>
            <td >NPM</td>
            <td width="40%">:A2.1100086</td>
            <td colspan="">TAHUN AKADEMIK/Semester</td>
            <td>:2014/2015/4</td>  
          </tr>
            <tr>
            <td>Nama</td>
            <td  width="40%">:AGIT NAETA</td>
            <td>Jurusan/Prog</td>
            <td colspan="">:Teknik Informatika/S1</td>
          </tr>
            <tr>
            
          </tr>
        </table>
            <table class="table table-condensed table-bordered">
            <thead>
                <th class="text-center">No</th><th class="text-center">Nama</th><th>Mata Kuliah</th><th>SKS</th><th>Tanggal</th><th>Paraf</th> 
            </thead>
                <tbody>
                <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                </tr>
                </tbody>
            </table>
        </div>
        <div class="col-md-2">4</div>
        </div></div>
    </body>
</html>
</a>