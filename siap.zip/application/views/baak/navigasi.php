                <div class="panel panel-primary">
                        <div class="panel-heading">
                             <h5>
                                 <i class="glyphicon glyphicon-th-large"></i> Menu                                                                 </h5>
						</div>
                        <div class="panel-body">
							<a href="<?php echo site_url('baak/utama') ;?>"  class="list-group-item">
                                <i class="glyphicon glyphicon-home "></i> Menu Utama</a>
					
                      
							<a href="<?php echo site_url('baak/khs_krs') ;?>" class="list-group-item ">
                                <i class="glyphicon glyphicon-print"></i> Cetak KHS & KRS </a>
						
                        
							<a href="<?php echo site_url('baak/cetak_absen') ;?>" class="list-group-item ">
                                <i class="glyphicon glyphicon-print"></i> Cetak Absen  </a>
						
                      
							<a href="<?php echo site_url('khs') ;?>" class="list-group-item" role="tab" data-toggle="tab">
                                <i class="glyphicon glyphicon-file"></i> Cetak Kartu Ujian </a>
					
                        
							<a href="<?php echo site_url('baak/kelola_user') ;?>"  class="list-group-item ">
                                <i class="glyphicon glyphicon-user"></i> Kelola User</a>
					
                        
							<a href="<?php echo site_url('baak/cek_password') ;?>"  class="list-group-item ">
                                <i class="glyphicon glyphicon-lock"></i> Password Mahasiswa</a>
					
                       
							<a href="<?php echo site_url('baak/utama/form_update');?>" class="list-group-item ">
                                <i class="glyphicon glyphicon-wrench"></i> Ubah Detail Akun</a>
                           
						</div>
                        <div class="panel-footer">
							<a href="<?php echo site_url('baak/utama/logout') ;?>" class="list-group-item ">
                                <i class="glyphicon glyphicon-off"></i> Selesai</a>
						</div>
					</div>