<!DOCTYPE html>
<html lang="en">
<head>
<title>SIAP ONLINE-MAHASISWA</title>
<link href="<?php echo base_url(); ?>src/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>src/css/flat.css" rel="stylesheet">
<script type="text/javascript" src="<?php echo base_url(); ?>src/js/jscek.js"></script>      
<script>
$(document).ready(function(){
        $('input[name="test"]').click(function(){
            if($(this).prop("checked") == true){
                $('.nilai').val('1');
            }
            else if($(this).prop("checked") == false){
                $('.nilai').val('0');
            }
        });
    });$(document).ready(function(){
        $('input[name="test"]').click(function(){
            if($(this).prop("checked") == true){
                $('.nilai').val('1');
            }
            else if($(this).prop("checked") == false){
                $('.nilai').val('0');
            }
        });
    });
</script>    
</head>